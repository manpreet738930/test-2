﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Content;

namespace project
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        SearchView srv;
        ListView lsv;
        Button addbtn;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
          

            srv = FindViewById<SearchView>(Resource.Id.sv);
            lsv = FindViewById<ListView>(Resource.Id.lv);
            addbtn = FindViewById<Button>(Resource.Id.addbtn);


            srv.QueryTextChange += (s, e) =>
              {

                  var adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1);
                  lsv.Adapter = adapter;
                  adapter.Filter.InvokeFilter(e.NewText);

              };



            addbtn.Click += delegate
            {
                Intent intent = new Intent(this, typeof());
                StartActivity(intent);
            };

        }
        protected override void OnRestart()
        {
            base.OnRestart();
            srv.SetQuery("", false);
            var adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1);
            lsv.Adapter = adapter;
        }
    }
}